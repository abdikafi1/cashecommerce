import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/product_controller.dart';
import 'checkout.dart'; // Import Checkout Page

class CartPage extends StatelessWidget {
  final ProductController productController = Get.find<ProductController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Your Cart')),
      body: Obx(() {
        if (productController.cart.isEmpty) {
          return Center(child: Text('Your cart is empty.'));
        }
        return ListView.builder(
          itemCount: productController.cart.length,
          itemBuilder: (context, index) {
            final item = productController.cart[index];
            return Card(
              margin: EdgeInsets.all(10),
              elevation: 5,
              child: ListTile(
                contentPadding: EdgeInsets.all(15),
                title: Text(item.product.name),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Price: \$${item.product.price}'),
                    Text('Quantity: ${item.quantity}'),
                  ],
                ),
                leading: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.network(
                    item.product.imageUrl,
                    width: 80,
                    height: 80,
                    fit: BoxFit.cover,
                  ),
                ),
                trailing: IconButton(
                  icon: Icon(Icons.remove_shopping_cart),
                  onPressed: () {
                    productController.removeFromCart(item.product);
                  },
                ),
              ),
            );
          },
        );
      }),
      bottomNavigationBar: BottomAppBar(
        child: ElevatedButton(
          onPressed: () {
            // Navigate to checkout page if cart is not empty
            if (productController.cart.isNotEmpty) {
              Get.to(CheckoutPage());
            } else {
              Get.snackbar(
                  'Cart Empty', 'Please add items to the cart to proceed.');
            }
          },
          child: Text('Proceed to Checkout'),
        ),
      ),
    );
  }
}
