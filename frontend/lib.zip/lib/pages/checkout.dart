import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/product_controller.dart';
import 'transaction.dart';

class CheckoutPage extends StatelessWidget {
  final ProductController productController = Get.find<ProductController>();

  @override
  Widget build(BuildContext context) {
    double totalAmount = productController.totalAmount;

    return Scaffold(
      appBar: AppBar(title: Text('Checkout')),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('Total: \$${totalAmount.toString()}'),
          ElevatedButton(
            onPressed: () async {
              try {
                await productController
                    .createTransaction(); // Create transaction
                Get.to(TransactionPage()); // Go to transaction page
              } catch (e) {
                Get.snackbar('Error', 'Failed to complete transaction');
              }
            },
            child: Text('Confirm Purchase'),
          ),
        ],
      ),
    );
  }
}

// import 'package:flutter/material.dart';
// import 'package:frontend/pages/transaction.dart';
// import 'package:get/get.dart';
// import '../controllers/product_controller.dart';

// class CheckoutPage extends StatelessWidget {
//   final ProductController productController = Get.find<ProductController>();

//   @override
//   Widget build(BuildContext context) {
//     double totalAmount =
//         productController.cart.fold(0.0, (sum, item) => sum + item.price);

//     return Scaffold(
//       appBar: AppBar(title: Text('Checkout')),
//       body: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Text('Total: \$${totalAmount.toString()}'),
//           ElevatedButton(
//             onPressed: () {
//               productController.clearCart();
//               Get.to(TransactionPage());
//             },
//             child: Text('Confirm Purchase'),
//           ),
//         ],
//       ),
//     );
//   }
// }
